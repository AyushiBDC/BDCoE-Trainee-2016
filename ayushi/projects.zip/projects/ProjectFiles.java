package myproject;
import java.math.*;
import java.sql.*;
import java.awt.*;
import java.awt.event.*;
import java.applet.*;
import java.util.regex.*;
import java.awt.geom.*;
import javax.swing.*;
import java.util.*;
import javax.mail.*;
import javax.mail.internet.*;
import javax.activation.*;
/*
*<applet code=OpenAccount width=1000 height=450>
*<param name=img value=bankmain.jpg>
*</applet>
*/
class OpenAccount extends JPanel implements ActionListener
{

JFrame f1;
JLabel l1,l2,l3,l4,l5,l6,l7,l8,l9,l10,l11,l12,l13;
JLabel s1,s2,s3,s4,s5,s6,s7,s8,s9,s10;
JTextField t1,t2,t3,t4,t5,t6,t9,t10,t11,t12;
Choice ch,ch2;  
Checkbox cbbus,cbser;
CheckboxGroup cbg1;
JButton btn1,btn2;
String Gender,Name;
BigInteger AadharNumber;

public OpenAccount()
{
f1=new JFrame();
setSize(1000,450);

//f1.setForeground(Color.red);
//f1.setBackground(Color.green);
Font font = new Font("Verdana",Font.BOLD, 16);
setFont(font);
//l13.setForeground(Color.black);
//l12.setForeground(Color.black);
f1.setVisible(true);
setLayout(new BorderLayout());
//	setContentPane(new JLabel(new ImageIcon("bankmain.jpg")));
	setLayout(new FlowLayout());
s1=new JLabel();
s2=new JLabel();
s3=new JLabel();
s4=new JLabel();
s5=new JLabel();
s6=new JLabel();
s7=new JLabel();

s8=new JLabel();
s9=new JLabel();
s10=new JLabel();

l1=new JLabel(".................WELCOME TO OPEN ACCOUNT SECTION.................");
l2=new JLabel("Full Name");
t1=new JTextField();
l3=new JLabel("Blood Group");
l4=new JLabel("Aadhar Number");
t4=new JTextField();
t5=new JTextField();

//t6=new TextField();
l5=new JLabel("Occupation");
l6=new JLabel("Gender");
l7=new JLabel("Email");
t2=new JTextField();
l8=new JLabel("Education");
ch2=new Choice();

ch2.addItem("INTERMEDIATE");
ch2.addItem("GRADUATE");
ch2.addItem("POSTGRADUATE");
ch2.addItem("NONE");
l9=new 	JLabel("Annual Turnover");
t3=new JTextField();
cbg1=new CheckboxGroup();
cbbus=new Checkbox("MALE",cbg1,true);
cbser=new Checkbox("FEMALE",cbg1,false);
btn1=new JButton("Exit");
btn2=new JButton("Submit");
ch=new Choice();
ch.addItem("Bussinesman");
ch.addItem("Serviceman");
ch.addItem("Student");
t9=new JTextField();
l10=new JLabel("Enter the security question:what is your nick name");
t10=new JTextField();
l11=new JLabel("Enter the password(Only no.)");
t11=new JTextField();
//t11.setEchoChar('*');
l12=new JLabel("Reenter the password");
t12=new JTextField();
//t12.setEchoChar('*');
t11.setBackground(Color.black);
t12.setBackground(Color.black);
t11.setForeground(Color.pink);
t12.setForeground(Color.pink);
l13=new JLabel();
f1.setVisible(true);
f1.setLayout(null);


add(l1);
add(t1);
add(l2);
add(s1);
add(l3);
add(t5);
add(s2);
add(l4);
add(t4);
add(s3);
//f1.add(t5);
//f1.add(t6);
add(l5);
add(cbbus);
f1.add(cbser);
add(s4);
add(l6);
add(ch);
add(l7);
add(t2);
add(s5);
add(l8);
add(ch2);
add(s6);
add(l9);
add(t3);
add(s7);
add(l10);
add(l13);
add(t10);
add(s8);
add(l11);
add(t11);
add(l12);
add(t12);
add(s10);
add(s9);
add(btn1);
add(btn2);
//f1.add(t9);
l1.setBounds(50,100,500,30);
l2.setBounds(50,150,100,30);
t1.setBounds(200,150,100,30);
s1.setBounds(500,150,300,30);
l3.setBounds(50,200,100,30);
l4.setBounds(50,250,130,30);
s2.setBounds(900,250,300,30);
t4.setBounds(200,250,500,30);
s3.setBounds(550,200,300,30);
t5.setBounds(200,200,100,30);
//t6.setBounds(420,250,100,30);


l5.setBounds(50,300,100,30);
s4.setBounds(500,350,300,30);
cbbus.setBounds(200,350,100,30);
cbser.setBounds(350,350,100,30);
l6.setBounds(50,350,100,30);
l7.setBounds(50,400,100,30);
s5.setBounds(500,400,300,30);
t2.setBounds(200,400,320,30);
l8.setBounds(50,450,100,30);
ch2.setBounds(200,450,130,30);
l9.setBounds(50,500,100,30);
s6.setBounds(500,150,300,30);
t3.setBounds(200,500,100,30);
l10.setBounds(50,550,400,30);
t10.setBounds(50,600,400,30);
s7.setBounds(500,150,300,30);
l11.setBounds(50,650,250,30);
t11.setBounds(300,650,130,30);
l12.setBounds(50,700,250,30);
s8.setBounds(500,150,300,30);
t12.setBounds(300,700,130,30);
btn1.setBounds(800,300,150,30);
btn2.setBounds(800,400,150,30);
ch.setBounds(200,300,130,30);
t9.setBounds(900,500,100,30);
s9.setBounds(500,150,300,30);
s10.setBounds(600,700,300,30);
l13.setBounds(900,550,400,130);
/*
if(t1.getText().matches("/^[a-z ,.'-]+$/i"))
{}
else
s1.setText("Enter valid details");
if(t5.getText().matches("^(?:AB|A|B|O)[-+]$"))
{}
else
s2.setText("Enter valid Group");
if(t4.getText().matches("^\\[0-9]\\d{9}$"))
{}
else
s3.setText("Enter valid Aadhar Number");

*/
t1.addActionListener(this);
t2.addActionListener(this);
t3.addActionListener(this);
t4.addActionListener(this);
t5.addActionListener(this);
t12.addActionListener(this);

btn1.addActionListener(this);
btn2.addActionListener(this);


}
public void actionPerformed(ActionEvent e)
{if(e.getSource()==t1)
{
if(t1.getText().matches("^[a-zA-Z\\s]*[^//d+]$"))
s1.setText(" ");
else
s1.setText("Enter valid details");
}

if(e.getSource()==t5)
{
if(t5.getText().matches("^[a b c o ab e][-+]$"))
{
s3.setText(" ");}
else
s3.setText("Enter valid Group");
}

if(e.getSource()==t4)
{
if(t4.getText().matches("^(\\[\\-\\s]?)?[0]?(91)?[0-9]\\d{9}$"))
{
s2.setText(" ");}
else
s2.setText("Enter valid Aadhar Number");
}

if(e.getSource()==t2)
{
if(t2.getText().matches("([\\w-\\.]+)@((?:[\\w]+\\.)+)([a-zA-Z]{2,4})"))
{
s5.setText(" ");
}
else
s5.setText("Enter valid email address");
}
if(e.getSource()==t12)
{
	try{
int f=Integer.parseInt(t11.getText());
int b=Integer.parseInt(t12.getText());
	if(f!=b)
s10.setText("Wrong value");
else
	s10.setText("");
	}
	catch(Exception se)
	{
	s10.setText("ENTER INTEGER VALUE");
}}

	
else if(e.getSource()==btn1)
{
System.exit(0);
}
else if(e.getSource()==btn2)
{
//if(s10.getText()==" ")
//{	
if(t4.getText().matches("^(\\+91[\\-\\s]?)?[0]?(91)?[0-9]\\d{9}$"))
{
t9.setText(" ");
int f=Integer.parseInt(t11.getText());
int b=Integer.parseInt(t12.getText());
if(f==b)
{
//t9.setText(" ");
try
{
Class.forName("com.mysql.jdbc.Driver");
Connection con=DriverManager.getConnection("jdbc:mysql://localhost/myproject?user=root&password=");
Name=t1.getText();
String BloodGroup=t5.getText();
AadharNumber= new BigInteger(t4.getText());
String Occupation=String.valueOf(ch.getSelectedItem());
if(cbbus.getState()==true)
Gender="male";
else if(cbser.getState()==true)
Gender="female";
String Email=t2.getText();
String Education=String.valueOf(ch2.getSelectedItem());
int Annual=Integer.parseInt(t3.getText());
String Code=t10.getText();
String Password=t11.getText();

PreparedStatement ps=con.prepareStatement("insert into customer (Name,BloodGroup,AadharNumber,Occupation,Gender,Email,Education,AnnualTurnover,Code,Password) values (?,?,?,?,?,?,?,?,?,?)");
ps.setString(1,Name);
ps.setString(2,BloodGroup);
ps.setLong(3,AadharNumber.longValue());
ps.setString(4,Occupation);
ps.setString(5,Gender);
ps.setString(6,Email);
ps.setString(7,Education);
ps.setInt(8,Annual);
ps.setString(9,Code);
ps.setString(10,Password);

int a=ps.executeUpdate();
if(a==1)
{
t9.setText("THANK YOU");
}
else
t9.setText("Some error occured.... :( ... try again");
ps=con.prepareStatement("Select AccountNumber from customer where Password=?");
ps.setString(1,Password);

ResultSet rs=ps.executeQuery();
if(rs.next())
{
int AccountNumber=rs.getInt(1);
l13.setText("Account Number "+AccountNumber);
}
con.close();
String to=Email;
String pass=Password;

String from="goelayushi707@gmail.com";
String mypassword="ayushi123";
String host="smtp.gmail.com";

Properties properties =new Properties();
properties.put("mail.host", host);
properties.put("mail.smtp.auth","true");
properties.put("mail.smtp.port", "465");
properties.setProperty("mail.transport.protocol", "smtp");
//properties.put("mail.smtp.localhost", "myHost");
//Session session = Session.getDefaultInstance(properties);
 properties.put("mail.smtp.socketFactory.class","javax.net.ssl.SSLSocketFactory");  
    properties.put("mail.smtp.socketFactory.fallback", "false");  
Session session = Session.getDefaultInstance(properties,
new javax.mail.Authenticator() {
protected PasswordAuthentication getPasswordAuthentication() {
return new PasswordAuthentication(from,mypassword);
}});


try
{
Transport transport = session.getTransport();
InternetAddress addressFrom = new InternetAddress(from);  
MimeMessage message = new MimeMessage(session);
//message.setFrom(new InternetAddress(from));
message.setSender(addressFrom);  
message.addRecipient(Message.RecipientType.TO, new InternetAddress(to));
message.setSubject("WELCOME TO BANK OF INDIA..........");
String p=String.valueOf(pass);
// byte[] encoded = Base64.encodeBase64(p.getBytes());       
//String res=new String(encoded);
//message.setText(p);
message.setText("World-class Indian Bank. We realised that only a single-minded focus on product quality and service excellence would help us get there. Today, we are proud to say that we are well on our way towards that goal.It is extremely gratifying that our efforts towards providing customer convenience have been appreciated both nationally and internationally.");

//message.addRecipient(Message.RecipientType.TO,
//new InternetAddress("elvis@presley.org"));
//STARTTLS;

//Transport.send(message);
transport.connect();
transport.send(message);
//message.getRecipients(Message.RecipientType.TO);
transport.close();

System.out.println("send....................");
f1.setVisible(false);
new Login();
 }
catch(Exception we)
{
System.out.println(we);
}
}
catch(Exception eA)
{
System.out.println("sorry................"+eA);
}}
else 
{
t11.setText(" ");
t12.setText(" ");
}
}
else
l13.setText("Enter valid Number");
}
}

/*public void paint(Graphics g)
{
Color c1=new Color(200,50,255);
g.setColor(Color.orange);
}*/
}



//.......CLASS DEPOSIT SECTION........
class DepositMoney extends JFrame implements ActionListener 
{
//JFrame f1;
//JTextField t1,t2,t3,t4;
JLabel l1,l2,l3,l4;
JButton btn1,btn2,btn3;
//boolean flag;


/*..........void DepositMoney()
{
flag=false;
Thread t=new Thread(this,"Deposit Thread");
//t.setName("Deposit thread");
f1=new Frame();
f1.setSize(450,650);
l1=new Label(".....................WELCOME TO MONEY DEPOSIT SECTION................");
l2=new Label("Enter your log in details first");
t2=new TextField();
t1=new TextField();
t3=new TextField();

f1.add(l1);
f1.add(l2);
f1.add(t2);
f1.add(t1);
l1.setBounds(50,100,200,30);
l2.setBounds(50,150,200,30);
t2.setBounds(50,200,200,30);
t1.setBounds(50,300,200,30);
f1.setVisible(true);
t.start();
}
public void run()
{
try
{
t2.setText("...REDIRECTING YOU TO LOG IN PAGE..............");
flag=true;
synchronized(this)
{
while(flag)

f1.setVisible(false);
new Login();
}
}
catch(Exception e)
{
f1.setVisible(false);
t1.setText("Error occured...........try after sometime :(");
System.out.println(e);
}
finally
{
f1.setVisible(true);
}
}
......................*/


public DepositMoney()
{
//f1=new JFrame();
setSize(900,1000);
setLocationRelativeTo(null);;
//f1.setBackground(Color.orange);
//f1.setForeground(Color.black);
setVisible(true);
setLayout(new BorderLayout());
	setContentPane(new JLabel(new ImageIcon("bankmain.jpg")));
	
Font font = new Font("Franklin Gothic",Font.BOLD, 100);
setFont(font);

l1=new JLabel("........WELCOME TO AMOUNT DEPOSIT AND WITHDRAW SECTION.....");
l2=new JLabel("You have to login into your account before you proceed");
btn1=new JButton("Login");
btn2=new JButton("Exit");


add(l1);
add(l2);
add(btn1);
add(btn2);
l1.setFont(new Font("Courier New", Font.BOLD, 40));
l2.setFont(new Font("Franklin Gothic", Font.ITALIC, 30));
setSize(899,999);
	setSize(900,1000);
	
	l1.setBounds(50,100,1000,30);
l2.setBounds(70,200,1000,30);
btn1.setBounds(100,450,200,30);
btn2.setBounds(600,450,200,30);
btn1.addActionListener(this);
btn2.addActionListener(this);
}
public void actionPerformed(ActionEvent e)
{
if(e.getSource()==btn1)
{
//f1.setVisible(false);
new Login();
}
else if(e.getSource()==btn2)
{
System.exit(0);
}
}
}



class Project extends JPanel implements ActionListener,TextListener
{
	Image img;
 JFrame frame;
Frame f1;
Label l1,l2,l3,l4,l5,l6,l7;
Button btn1,btn2;
TextField t1,t2;
public Project() 
{
frame = new JFrame();
frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
f1=new Frame();
f1.setSize(700,800);
//MediaTracker mt=new MediaTracker(this);
//img=Toolkit.getDefaultToolkit().getImage("bankmain.jpg");
//mt.addImage(img,0);

//Panel panel=new Panel();
//f1.add(panel);
//f1.getComponent(0).setBackground(Color.GREEN);
//panel.setBackground(Color.BLUE);
//f1.setForeground(Color.magenta);
//f1.setBackground(Color.yellow);
Font font = new Font("Verdana",Font.BOLD, 13);
f1.setFont(font);

f1.setLayout(null);
l1=new Label("..............BANK MENU.................");
l2=new Label("1.OPEN ACCOUNT ");
l3=new Label("2.DEPOSIT MONEY");
l4=new Label("3.WITHDRAW MONEY");
l5=new Label("4.BALANCE MONEY");
l6=new Label("..........................ENTER YOUR CHOICE............................");
t1=new TextField();
l7=new Label(" ");
btn1=new Button("Exit");
btn2=new Button("Submit");
f1.add(l1);
f1.add(l2);
f1.add(l3);
f1.add(l4);
f1.add(l5);
f1.add(l6);
f1.add(t1);
f1.add(l7);
f1.add(btn1);
f1.add(btn2);
f1.setLayout(null);
l1.setBounds(50,100,150,30);
l2.setBounds(50,150,150,30);
l3.setBounds(50,200,150,30);
l4.setBounds(50,250,150,30);
l5.setBounds(50,300,150,30);
l6.setBounds(50,450,300,30);
t1.setBounds(50,490,150,30);
l7.setBounds(300,490,150,30);
btn1.setBounds(50,550,130,30);
btn2.setBounds(150,550,130,30);
t1.addTextListener(this);


f1.setVisible(true);
btn1.addActionListener(this);
btn2.addActionListener(this);

}
public void textValueChanged(TextEvent te)
{
	if(te.getSource()==t1)
	{
		int n=Integer.parseInt(t1.getText());
		if(n>4||n==0)
			l7.setText("Enter valid result");
		else
			l7.setText("");
		
	}
	
}
public void actionPerformed(ActionEvent e)
{
if(e.getSource()==btn2)
{
int ch=Integer.parseInt(t1.getText());
if(ch>0&&ch<5)
{
if(ch==1)
{
f1.setVisible(false);
new OpenAccount();
}
else if(ch==2)
{
new DepositMoney();
}
else if(ch==3)
{
new DepositMoney();
}
else if(ch==4)
	new Login();}
else
l7.setText("ENTER VALID OPTION");
}
else if(e.getSource()==btn1)
{
System.exit(0);
}}
}



class ProjectFiles extends Frame
{
public static void main(String args[])
{
new Project();
}
}