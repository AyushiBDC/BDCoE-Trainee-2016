package myproject;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.applet.Applet;
import javax.swing.SwingUtilities;
import javax.swing.*;
import java.util.*;
import javax.mail.*;
import javax.mail.internet.*;
import javax.activation.*;
//import javax.xml.bind.DatatypeConverter;


class Login extends JFrame implements ActionListener
{
JLabel l1,l2,l3,l4;
JTextField t1;
JTextField t2;
JButton btn1,btn2,btn3,btn4,btn5;
public int g=0;
String uname;
int pass;


public Login()
{
//f1=new Frame();
setSize(1000,650);
//f1.setBackground(Color.pink);
//f1.setForeground(Color.black);
//Font font = new Font("Bauhaus 93",Font.BOLD, 16);
//f1.setFont(font);

setLocationRelativeTo(null);
setVisible(true);
setLayout(new BorderLayout());
	setContentPane(new JLabel(new ImageIcon("Login.jpg")));
	
l1=new JLabel("Enter User Name");
t1=new JTextField();
l2=new JLabel("Enter password");
t2=new JTextField();
//JPasswordField t2= new JPasswordField();
//t2.setEchoChar('*');
btn1=new JButton("Login");
btn2=new JButton("Reset");
btn3=new JButton("Exit");
btn4=new JButton("FORGOT PASSWORD");
btn5=new JButton("DISPLAY DETAILS");

//l4=new Label("FORGOT PASSWORD");
l3=new JLabel(" ");
l1.setFont(new Font("Courier New", Font.BOLD, 20));
l2.setFont(new Font("Franklin Gothic", Font.BOLD, 20));



add(l1);
add(t1);
add(l2);
add(t2);
add(btn1);
add(btn2);
add(btn3);
add(btn4);
add(btn5);
add(l3);
l1.setBounds(100,100,250,30);
t1.setBounds(400,100,100,30);

l2.setBounds(100,150,250,30);
t2.setBounds(400,150,100,30);

btn1.setBounds(100,200,100,30);
btn2.setBounds(300,200,100,30);
btn3.setBounds(500,200,100,30);
btn4.setBounds(100,300,800,30);
btn5.setBounds(50,250,500,30);
l3.setBounds(100,250,100,30);


setVisible(true);
btn1.addActionListener(this);
btn2.addActionListener(this);
btn3.addActionListener(this);
btn4.addActionListener(this);
btn5.addActionListener(this);
t2.addActionListener(this);

//Frame.setDefaultCloseOperation(Frame.EXIT_ON_CLOSE);

/*f1.addWindowListener(
  new WindowAdapter(){
    public void windowClosed(WindowEvent e) { System.exit(0); }
  }
);*/
}

public void actionPerformed(ActionEvent e)
{
if(e.getSource()==btn1)
{
try
{
Class.forName("com.mysql.jdbc.Driver");
Connection con=DriverManager.getConnection("jdbc:mysql://localhost/myproject?user=root&password=");
uname=t1.getText();
/*char[] input=t2.getPassword();
		String s=String.valueOf(t2.getPassword());
		pass=Integer.parseInt(s);*/
pass=Integer.parseInt(t2.getText());
PreparedStatement ps=con.prepareStatement("Select * from customer where Name=? and Password=?");
ps.setString(1,uname);
ps.setInt(2,pass);
ResultSet rs=ps.executeQuery();
if(rs.next())
{
setVisible(false);
l3.setText("welcome");

new Choose(uname,pass);
}
else 
{
l3.setText("INVALID USERNAME AND PASSWORD");
t1.setText(" ");
t2.setText(" ");
}
}
catch(Exception ee)
{
System.out.println(ee);
}
}
else if(e.getSource()==btn2)
{
t1.setText(" ");
t2.setText(" ");
}
else if(e.getSource()==btn3)
{
System.exit(0);
}
else if(e.getSource()==btn4)
{
setVisible(false);
new ForgotPassword();
}
else if(e.getSource()==btn5)
{
setVisible(false);
uname=t1.getText();
/*
char[] input=t2.getPassword();
		String s=input.toString();*/
//String p=String.ValueOf(t2.getPassword());
pass=Integer.parseInt(t2.getText());
new Display(uname,pass);
}


}
}



class Display extends JFrame implements ActionListener
{
	//Frame f1;
	JLabel l1,l2,l3,l4,l5,l6,l7,l8,l9,l10,l0;
	JButton btn1,btn2;
	String uname;
	int pass;
	public Display(String name,int pas)
	{
	
		uname=name;
		pass=pas;
	//	f1=new Frame();
		setSize(900,1000);
	
//f1.setBackground(Color.red);
//f1.setForeground(Color.black);
Font font = new Font("Lucida Calligraphy",Font.BOLD, 16);
setFont(font);
setVisible(true);
setLocationRelativeTo(null);

setLayout(new BorderLayout());
	setContentPane(new JLabel(new ImageIcon("display.jpg")));

l0=new JLabel("DETAILS.............");

	l1=new JLabel("USER NAME:");
		l5=new JLabel(" ");
		l2=new JLabel("Account number :");
		l6=new JLabel("");
		l3=new JLabel("Blood Group:");
		l7=new JLabel("");
		l4=new JLabel("Gender :");
		l8=new JLabel("");
		l10=new JLabel("Balance :");
		l9=new JLabel("");
		btn1=new JButton("Exit");
		btn2=new JButton("Home");
	
		//System.out.println(uname);
	
		
try
{
Class.forName("com.mysql.jdbc.Driver");
Connection con=DriverManager.getConnection("jdbc:mysql://localhost/myproject?user=root&password=");
PreparedStatement ps=con.prepareStatement("Select Name,AccountNumber,BloodGroup,Gender,Amount from customer where Name=? and Password=?");
ps.setString(1,uname);
ps.setInt(2,pass);
ResultSet rs=ps.executeQuery();
if(rs.next())
{
	String Name;
	String BloodGroup;
	String Gender;
	int AccountNumber,Amount;
	//System.out.println(Name);
 Name=rs.getString(1);
 AccountNumber=rs.getInt(2);
BloodGroup =rs.getString(3);
Gender=rs.getString(4);
Amount=rs.getInt(5);
//System.out.println(Name);
l5.setText(""+Name);
//String Account=String.valueOf(AccountNumber);
l6.setText(""+AccountNumber);
l7.setText(""+BloodGroup);
l8.setText(""+Gender);
//Amount=String.valueOf(Amount);
l9.setText(""+Amount);

}
con.close();
}
catch(Exception se){
	setVisible(false);
	System.out.println(se);
}

setLayout(null);


add(l0);
		add(l1);
		add(l5);
		add(l2);
		add(l6);
		add(l3);
		add(l7);
		add(l4);
		add(l8);
		//f1.add(l8);
		add(l10);
		add(l9);
		
		
		add(btn1);
		add(btn2);
	
	l0.setFont(new Font("Courier New", Font.BOLD, 40));
l1.setFont(new Font("Franklin Gothic", Font.ITALIC, 20));
l5.setFont(new Font("Franklin Gothic", Font.ITALIC, 20));
l2.setFont(new Font("Franklin Gothic", Font.ITALIC, 20));

l6.setFont(new Font("Franklin Gothic", Font.ITALIC, 20));
l3.setFont(new Font("Franklin Gothic", Font.ITALIC, 20));
l7.setFont(new Font("Franklin Gothic", Font.ITALIC, 20));
l4.setFont(new Font("Franklin Gothic", Font.ITALIC, 20));
l8.setFont(new Font("Franklin Gothic", Font.ITALIC, 20));
l10.setFont(new Font("Franklin Gothic", Font.ITALIC, 20));
l9.setFont(new Font("Franklin Gothic", Font.ITALIC, 20));
setSize(899,999);
	setSize(900,1000);
	


	l0.setBounds(200,100,900,50);
		l1.setBounds(200,200,200,30);
		l5.setBounds(800,200,200,30);
		l2.setBounds(200,250,200,30);
		l6.setBounds(800,250,200,30);
		l3.setBounds(200,300,200,30);
		l7.setBounds(800,300,200,30);
		l4.setBounds(200,350,200,30);
		l8.setBounds(800,350,200,30);
		l10.setBounds(200,400,200,30);
		l9.setBounds(800,400,200,30);
		
		btn1.setBounds(200,500,200,30);
		btn2.setBounds(200,550,200,30);
				
		btn1.addActionListener(this);
		btn2.addActionListener(this);
		
	}
	
	public void actionPerformed(ActionEvent e)
	{
		if(e.getSource()==btn1)
		{
System.exit(0);
			
		}
else if(e.getSource()==btn2)	
{
	setVisible(false);
	new Project();
}	
	}
	
}


class ForgotPassword extends JFrame implements ActionListener
{JLabel l1,l2,l3,l4;
JTextField t1,t2;
JButton btn1,btn2;
String uname,email;
int pass;
public ForgotPassword()
{
//f1=new Frame();
setSize(900,1000);
//f1.setBackground(Color.green);
//f1.setForeground(Color.blue);
Font font = new Font("Elephant",Font.BOLD, 16);
setFont(font);
setLocationRelativeTo(null);

setVisible(true);
setLayout(new BorderLayout());
	setContentPane(new JLabel(new ImageIcon("choose.jpg")));

l1=new JLabel("FORGOT PASSWORD");
l2=new JLabel("Enter your Account no");
t1=new JTextField();
//t1.setToolTipText("ACCOUNT NO");
l3=new JLabel("Enter your pet name");
t2=new JTextField();
//t2.setToolTipText("SECURITY QUESTION");
l4=new JLabel("We are sending the details to the email provided at verification time");
btn1=new JButton("NEXT");
btn2=new JButton("EXIT");
l1.setFont(new Font("Elephant", Font.BOLD, 40));
l2.setFont(new Font("Franklin Gothic", Font.ITALIC, 30));
l3.setFont(new Font("Franklin Gothic", Font.ITALIC, 30));
setSize(899,999);
	setSize(900,1000);


add(l1);
add(l2);
add(t1);
add(l3);
add(t2);
add(l4);
add(btn1);
add(btn2);

l1.setBounds(50,200,800,30);
l2.setBounds(50,250,300,30);
t1.setBounds(500,250,150,30);
l3.setBounds(50,300,300,30);
t2.setBounds(500,300,300,30);
l4.setBounds(50,350,800,30);
btn1.setBounds(50,400,300,30);
btn2.setBounds(50,450,300,30);

btn1.addActionListener(this);
btn2.addActionListener(this);
btn1.setForeground(Color.red);
btn2.setForeground(Color.red);
}
public void actionPerformed(ActionEvent e)
{
	if(e.getSource()==btn1)
{
try
{
int AccountNumber=Integer.parseInt(t1.getText());
String Code=t2.getText();

Class.forName("com.mysql.jdbc.Driver");
Connection con=DriverManager.getConnection("jdbc:mysql://localhost/myproject?user=root&password=");
PreparedStatement ps=con.prepareStatement("Select Name,Password,email from customer where AccountNumber=?&&Code=?");
ps.setInt(1,AccountNumber);
ps.setString(2,Code);

ResultSet rs=ps.executeQuery();
if(rs.next())
{
uname=rs.getString(1);
pass=rs.getInt(2);
email=rs.getString(3);
setVisible(false);
new SendMail(uname,pass,email);
}
}
catch(Exception fe)
{System.out.println(fe);
}

}
else if(e.getSource()==btn2)
{
	setVisible(false);
System.exit(0);
}
}

}

class SendMail 
{
String uname,to;
int pass;

public SendMail(String name,int pas,String mail)
{
uname=name;
pass=pas;
to=mail;
//String to="goelayushi701@gmail";
String from="goelayushi707@gmail.com";
String mypassword="ayushi123";
String host="smtp.gmail.com";

Properties properties =new Properties();
properties.put("mail.host", host);
properties.put("mail.smtp.auth","true");
properties.put("mail.smtp.port", "465");
properties.setProperty("mail.transport.protocol", "smtp");
//properties.put("mail.smtp.localhost", "myHost");
//Session session = Session.getDefaultInstance(properties);
 properties.put("mail.smtp.socketFactory.class","javax.net.ssl.SSLSocketFactory");  
    properties.put("mail.smtp.socketFactory.fallback", "false");  
Session session = Session.getDefaultInstance(properties,
new javax.mail.Authenticator() {
protected PasswordAuthentication getPasswordAuthentication() {
return new PasswordAuthentication(from,mypassword);
}});


try
{
Transport transport = session.getTransport();
InternetAddress addressFrom = new InternetAddress(from);  
MimeMessage message = new MimeMessage(session);
//message.setFrom(new InternetAddress(from));
message.setSender(addressFrom);  
message.addRecipient(Message.RecipientType.TO, new InternetAddress(to));
message.setSubject("Account open mail!..........your password is given below");
String p=String.valueOf(pass);
// byte[] encoded = Base64.encodeBase64(p.getBytes());       
//String res=new String(encoded);
//message.setText(p);
message.setText(p);

//message.addRecipient(Message.RecipientType.TO,
//new InternetAddress("elvis@presley.org"));
//STARTTLS;

//Transport.send(message);
transport.connect();
transport.send(message);
//message.getRecipients(Message.RecipientType.TO);
transport.close();

System.out.println("send....................");
new Login();
 }
catch(Exception we)
{
System.out.println(we);
}
}
}


class Choose extends JFrame implements ActionListener
{
JTextField t1,t2,t3,t4;
JLabel l1,l2,l3,l4;
JButton btn1,btn2,btn3;
String name;
int pas;
public Choose(String uname,int pass)
{
name=uname;
pas=pass;
//f1=new Frame();
setSize(900,1000);
setLocationRelativeTo(null);
//f1.setBackground(Color.blue);
//f1.setForeground(Color.black);
Font font = new Font(" Forte"  ,Font.BOLD, 16);
setFont(font);
setVisible(true);
setLayout(new BorderLayout());
	setContentPane(new JLabel(new ImageIcon("choose.jpg")));

l1=new JLabel("........WELCOME TO AMOUNT DEPOSIT AND WITHDRAW SECTION.....");
l2=new JLabel("");
btn1=new JButton("Withdraw");
btn2=new JButton("Deposit");
btn3=new JButton("exit");
l1.setFont(new Font("Forte", Font.BOLD, 40));
l2.setFont(new Font("Forte", Font.ITALIC, 30));
setVisible(true);

add(l1);
add(l2);
add(btn1);
add(btn2);
add(btn3);
setSize(899,999);
setSize(900,1000);
//setLayout(null);
l1.setBounds(20,100,1300,30);
l2.setBounds(50,200,800,30);
btn1.setBounds(50,250,200,30);
btn2.setBounds(400,250,200,30);
btn3.setBounds(50,300,200,30);

btn1.addActionListener(this);
btn2.addActionListener(this);
btn3.addActionListener(this);

}
public void actionPerformed(ActionEvent e)
{
if(e.getSource()==btn1)
{
setVisible(false);
new Deposit(name,pas);
}
else if(e.getSource()==btn2)
{
setVisible(false);
new AfterLogin(name,pas);
}
else if(e.getSource()==btn3)
{
System.exit(0);
}
}
}



class AfterLogin extends JFrame implements ActionListener
{
//Frame f1;
JLabel l1,l2,l3,l4,l5,l6,l7,l8,l9;
JTextField t1,t2,t3,t4,t5,t6;
JButton btn1,btn3;
String Name;
int AccountNumber;
int balance,o;
String uname;
int pass;
public AfterLogin(String nam,int paswr)
{
uname=nam;
pass=paswr;
//f1=new Frame();
setSize(450,600);
setVisible(true);
setLocationRelativeTo(null);
//f1.setBackground(Color.yellow);
//f1.setForeground(Color.blue);
Font font = new Font("Franklin Gothic",Font.BOLD, 16);
setFont(font);
setLayout(new BorderLayout());
	setContentPane(new JLabel(new ImageIcon("after.jpg")));
	
l1=new JLabel("....YOUR ACCOUNT ...");
l2=new JLabel("NAME");
l6=new JLabel(" ");
l3=new JLabel("Account Number");
l7=new JLabel(" ");
l4=new JLabel("Your current balance :");
l8=new JLabel(" ");
l5=new JLabel("Enter the amount you want to deposit");
t4=new JTextField();
t5=new JTextField();
t6=new JTextField();
l9=new JLabel(" ");
btn1=new JButton("Submit");
btn3=new JButton("Exit");
l1.setFont(new Font("Courier New", Font.BOLD, 40));
//l2.setFont(new Font("Franklin Gothic", Font.ITALIC, 30));
try
{
Class.forName("com.mysql.jdbc.Driver");
Connection con=DriverManager.getConnection("jdbc:mysql://localhost/myproject?user=root&password=");
PreparedStatement ps=con.prepareStatement("Select Name,AccountNumber,Amount from customer where Name=?&&Password=?");
ps.setString(1,uname);
ps.setInt(2,pass);
ResultSet rs=ps.executeQuery();
if(rs.next())
{
 Name=rs.getString(1);
 AccountNumber=rs.getInt(2);
 balance =rs.getInt(3);
}
else
{}
con.close();
}
catch(Exception ae)
{
	l9.setText("try later");
}
l6.setText(" "+Name);
l7.setText(" "+AccountNumber);
l8.setText(" "+balance);

add(l1);
add(l2);
add(l6);
add(l3);
add(l7);
add(l4);
add(l8);
add(l5);
add(t4);
add(t5);
add(t6);
add(btn1);
add(btn3);
add(l9);
l1.setBounds(50,100,800,30);
l2.setBounds(50,200,150,30);
l6.setBounds(500,200,150,30);
l3.setBounds(50,300,150,30);
l7.setBounds(500,300,150,30);
l4.setBounds(50,400,150,30);
l8.setBounds(500,400,150,30);
l5.setBounds(50,500,400,30);
t4.setBounds(500,500,150,30);
//l9.setBounds(50,650,150,30);
btn1.setBounds(50,600,150,30);
btn3.setBounds(50,650,150,30);
l9.setBounds(50,750,750,90);
o=pass;
btn1.addActionListener(this);
btn3.addActionListener(this);


}
public void actionPerformed(ActionEvent e)
{
if(e.getSource()==btn3)
{
System.exit(0);
}
else if(e.getSource()==btn1)
{
try{
Class.forName("com.mysql.jdbc.Driver");
Connection con=DriverManager.getConnection("jdbc:mysql://localhost/myproject?user=root&password=");
int pass=o;
int dep=Integer.parseInt(t4.getText());
PreparedStatement ps=con.prepareStatement("Update customer set Amount=Amount+? where Name=?&&Password=?");
ps.setInt(1,dep);
ps.setString(2,uname);
ps.setInt(3,pass);

int a=ps.executeUpdate();

if(a==1)
{
l9.setText("RECORD UPDATED");
System.out.println("updated");
setVisible(false);
new Login();
}
else
l9.setText("RECORD NOT UPDATED");
}
catch(Exception ae)
{
System.out.println(ae);
}
}
}}



class Deposit implements ActionListener,TextListener
{

Frame f1;
Label l1,l2,l3,l4,l5,l6,l7,l8,l9,l10;
TextField t1,t2,t3,t4,t5,t6;
Button btn1,btn3;
String Name;
int AccountNumber;
int balance,o;
String uname;
int pass;
public Deposit(String nam,int paswr)
{
uname=nam;
pass=paswr;
f1=new Frame();
f1.setSize(550,900);
f1.setVisible(true);
f1.setBackground(Color.orange);
f1.setForeground(Color.blue);
Font font = new Font("Rockwell",Font.BOLD, 16);
f1.setFont(font);


l1=new Label("....YOUR ACCOUNT SECTION ...");
l2=new Label("NAME");
l6=new Label(" ");
l3=new Label("Account Number");
l7=new Label(" ");
l4=new Label("Your current balance :");
l8=new Label(" ");
l5=new Label("Enter the amount you want to withdraw");
t4=new TextField();


l10=new Label(" ");
t6=new TextField();
l9=new Label(" ");
btn1=new Button("Submit");
btn3=new Button("Exit");
try
{
Class.forName("com.mysql.jdbc.Driver");
Connection con=DriverManager.getConnection("jdbc:mysql://localhost/myproject?user=root&password=");
PreparedStatement ps=con.prepareStatement("Select Name,AccountNumber,Amount from customer where Name=?&&Password=?");
ps.setString(1,uname);
ps.setInt(2,pass);
ResultSet rs=ps.executeQuery();
if(rs.next())
{
 Name=rs.getString(1);
 AccountNumber=rs.getInt(2);
 balance =rs.getInt(3);
}
else
{}
con.close();
}
catch(Exception ae)
{
	l10.setText("Enter valid amount");
}
l6.setText(" "+Name);
l7.setText(" "+AccountNumber);
l8.setText(" "+balance);

f1.add(l1);
f1.add(l2);
f1.add(l6);
f1.add(l3);
f1.add(l7);
f1.add(l4);
f1.add(l8);
f1.add(l5);
f1.add(t4);
f1.add(l10);
f1.add(t6);
f1.add(btn1);
f1.add(btn3);
f1.add(l9);
l1.setBounds(50,100,800,30);
l2.setBounds(50,200,150,30);
l6.setBounds(500,200,150,30);
l3.setBounds(50,300,150,30);
l7.setBounds(500,300,150,30);
l4.setBounds(50,400,150,30);
l8.setBounds(500,400,150,30);
l5.setBounds(50,500,400,30);
t4.setBounds(500,500,150,30);
l10.setBounds(700,500,500,30);
btn1.setBounds(50,600,150,30);
btn3.setBounds(50,650,150,30);
l9.setBounds(50,750,200,90);
o=pass;
btn1.addActionListener(this);
btn3.addActionListener(this);
t4.addTextListener(this);

}
public void textValueChanged(TextEvent te)
  {
if(te.getSource()==t4)
{
	try{
int dep=Integer.parseInt(t4.getText());
if(dep>balance)
l10.setText("NOT ENOUGH BALANCE IN ACCOUNT");
else
l10.setText(" ");}
catch(Exception d)
{
l10.setText("Enter valid no");
}
}
}
public void actionPerformed(ActionEvent e)
{
if(e.getSource()==btn3)
{
System.exit(0);
}
else if(e.getSource()==btn1)
{
int dep=Integer.parseInt(t4.getText());
if(dep>balance)
{
l9.setText("Enter a valid amount");
t4.setText(" ");
}
else
{
try{
Class.forName("com.mysql.jdbc.Driver");
Connection con=DriverManager.getConnection("jdbc:mysql://localhost/myproject?user=root&password=");
int pass=o;
PreparedStatement ps=con.prepareStatement("Update customer set Amount=Amount-? where Name=?&&Password=?");
ps.setInt(1,dep);
ps.setString(2,uname);
ps.setInt(3,pass);

int a=ps.executeUpdate();

if(a==1)
l9.setText("RECORD UPDATED");
else
l9.setText("RECORD NOT UPDATED");
}
catch(Exception ae)
{
l10.setText("Enter valid amount");
}
}
}}
}




class UserLogin
{
public static void main(String args[])
{
new Login();
//new AfterLogin();
}
}